const db = require("../config/db");
const bcrypt = require("bcrypt");

// Get All Employees
exports.getEmployees = async (req, res) => {
  try {
    const { organization_id } = req.query;

    if (!organization_id) {
      return res.status(400).json({
        success: false,
        message: "organization_id is required"
      });
    }

    const sql = `
      SELECT 
        e.*,
        d.name AS department_name,
        des.name AS designation_name,
        rm.employee_code AS reporting_manager_code
      FROM employees e
      LEFT JOIN departments d
        ON e.department_id = d.id
      LEFT JOIN designations des
        ON e.designation_id = des.id
      LEFT JOIN employees rm
        ON e.reporting_manager_id = rm.id
      WHERE e.organization_id = ?
    `;

    const [result] = await db.query(sql, [organization_id]);

    res.status(200).json({
      success: true,
      data: result
    });

  } catch (err) {
    console.log(err);

    res.status(500).json({
      success: false,
      message: "Failed to fetch employees",
      error: err.message
    });
  }
};


// Get Employes By Id
exports.getEmployeeById = async (req, res) => {

  try {

    const { id } = req.params;

    const [result] = await db.query(
      `
      SELECT
        e.*,
        d.name AS department_name,
        des.name AS designation_name,
        rm.employee_code AS reporting_manager_code

      FROM employees e

      LEFT JOIN departments d
      ON e.department_id = d.id

      LEFT JOIN designations des
      ON e.designation_id = des.id

      LEFT JOIN employees rm
      ON e.reporting_manager_id = rm.id

      WHERE e.id = ?
      `,
      [id]
    );

    if (!result.length) {
      return res.status(404).json({
        success:false,
        message:"Employee not found"
      });
    }

    res.json({
      success:true,
      data:result[0]
    });

  } catch (err) {

    res.status(500).json({
      success:false,
      error:err.message
    });

  }

};


exports.addEmployee = async (req, res) => {

  try {

    const {
      organization_id,
      user_id,
      employee_code,
      department_id,
      designation_id,
      reporting_manager_id,
      joining_date,
      employment_type,
      work_location,
      status
    } = req.body;

    const [result] = await db.query(
      `
      INSERT INTO employees(
        organization_id,
        user_id,
        employee_code,
        department_id,
        designation_id,
        reporting_manager_id,
        joining_date,
        employment_type,
        work_location,
        status
      )

      VALUES(
        ?,?,?,?,?,?,?,?,?,?
      )
      `,
      [
        organization_id,
        user_id,
        employee_code,
        department_id || null,
        designation_id || null,
        reporting_manager_id || null,
        joining_date || null,
        employment_type || "full_time",
        work_location || null,
        status || "active"
      ]
    );

    res.status(201).json({
      success:true,
      message:"Employee added successfully",
      employeeId:result.insertId
    });

  } catch (err) {

    console.log(err);

    res.status(500).json({
      success:false,
      error:err.message
    });

  }

};


// Update Employee
exports.updateEmployee = async (req, res) => {

  try {

    const { id } = req.params;

    const {
      organization_id,
      department_id,
      designation_id,
      reporting_manager_id,
      joining_date,
      employment_type,
      work_location,
      status
    } = req.body;

    await db.query(
      `
      UPDATE employees

      SET
      organization_id=?,
      department_id=?,
      designation_id=?,
      reporting_manager_id=?,
      joining_date=?,
      employment_type=?,
      work_location=?,
      status=?

      WHERE id=?
      `,
      [
        organization_id,
        department_id,
        designation_id,
        reporting_manager_id,
        joining_date,
        employment_type,
        work_location,
        status,
        id
      ]
    );

    res.json({
      success:true,
      message:"Employee updated successfully"
    });

  } catch (err) {

    res.status(500).json({
      success:false,
      error:err.message
    });

  }

};

exports.deleteEmployee = async (req, res) => {

  try {

    const { id } = req.params;

    await db.query(
      `DELETE FROM employees WHERE id=?`,
      [id]
    );

    res.json({
      success:true,
      message:"Employee deleted successfully"
    });

  } catch (err) {

    res.status(500).json({
      success:false,
      error:err.message
    });

  }

};