const db = require("../config/db");
const bcrypt = require("bcrypt");


exports.createOrganization = async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();
        
        const {
            organization_code,
            name,
            email,
            phone,
            address,
            city,
            state,
            country,
            postal_code,
            website,
            subscription_plan = 'trial',
            subscription_end_date,
            max_employees = 100,
            max_departments = 10,
            admin_email,
            admin_password,
            admin_first_name,
            admin_last_name,
            admin_phone
        } = req.body;
        
        // Check if organization code exists
        const [existingOrg] = await connection.query(
            "SELECT id FROM organizations WHERE organization_code = ? OR email = ?",
            [organization_code, email]
        );
        
        if (existingOrg.length > 0) {
            await connection.rollback();
            return res.status(400).json({
                success: false,
                message: "Organization code or email already exists"
            });
        }
        
        // Calculate subscription dates
        const startDate = new Date();
        let endDate = null;
        if (subscription_end_date) {
            endDate = new Date(subscription_end_date);
        } else if (subscription_plan === 'trial') {
            endDate = new Date();
            endDate.setDate(endDate.getDate() + 30); // 30 days trial
        }
        
        // Insert organization
        const [orgResult] = await connection.query(
            `INSERT INTO organizations 
             (organization_code, name, email, phone, address, city, state, country, 
              postal_code, website, subscription_plan, subscription_start_date, 
              subscription_end_date, max_employees, max_departments, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
            [organization_code, name, email, phone, address, city, state, country, 
             postal_code, website, subscription_plan, startDate, endDate, 
             max_employees, max_departments]
        );
        
        const organizationId = orgResult.insertId;
        
        // Hash admin password
        const hashedPassword = await bcrypt.hash(admin_password, 10);
        
        // Create organization admin user
        const [userResult] = await connection.query(
            `INSERT INTO users 
             (organization_id, email, password, first_name, last_name, phone, role, is_active) 
             VALUES (?, ?, ?, ?, ?, ?, 'org_admin', true)`,
            [organizationId, admin_email, hashedPassword, admin_first_name, admin_last_name, admin_phone]
        );
        
        // Create employee record for the admin
        const employeeCode = `EMP${organizationId}${Date.now()}`;
        await connection.query(
            `INSERT INTO employees 
             (organization_id, user_id, employee_code, joining_date, employment_type, status) 
             VALUES (?, ?, ?, CURDATE(), 'full_time', 'active')`,
            [organizationId, userResult.insertId, employeeCode]
        );
        
        await connection.commit();
        
        res.status(201).json({
            success: true,
            message: "Organization created successfully",
            data: {
                organization_id: organizationId,
                organization_code,
                name,
                admin_email
            }
        });
        
    } catch (err) {
        await connection.rollback();
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to create organization",
            error: err.message
        });
    } finally {
        connection.release();
    }
};

// Get all organizations (super admin only)
exports.getAllOrganizations = async (req, res) => {
    try {
        const [result] = await db.query(`
            SELECT 
                o.*,
                COUNT(DISTINCT u.id) as total_users,
                COUNT(DISTINCT e.id) as total_employees,
                COUNT(DISTINCT d.id) as total_departments
            FROM organizations o
            LEFT JOIN users u ON o.id = u.organization_id
            LEFT JOIN employees e ON o.id = e.organization_id
            LEFT JOIN departments d ON o.id = d.organization_id
            GROUP BY o.id
            ORDER BY o.created_at DESC
        `);
        
        res.status(200).json({
            success: true,
            data: result
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to fetch organizations",
            error: err.message
        });
    }
};

// Get organization by ID
exports.getOrganizationById = async (req, res) => {
    try {
        const { id } = req.params;
        
        const [result] = await db.query(`
            SELECT 
                o.*,
                COUNT(DISTINCT u.id) as total_users,
                COUNT(DISTINCT e.id) as total_employees,
                COUNT(DISTINCT d.id) as total_departments
            FROM organizations o
            LEFT JOIN users u ON o.id = u.organization_id
            LEFT JOIN employees e ON o.id = e.organization_id
            LEFT JOIN departments d ON o.id = d.organization_id
            WHERE o.id = ?
            GROUP BY o.id
        `, [id]);
        
        if (!result.length) {
            return res.status(404).json({
                success: false,
                message: "Organization not found"
            });
        }
        
        res.status(200).json({
            success: true,
            data: result[0]
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to fetch organization",
            error: err.message
        });
    }
};

// Update organization
exports.updateOrganization = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        
        const allowedUpdates = ['name', 'email', 'phone', 'address', 'city', 'state', 
                                'country', 'postal_code', 'website', 'logo_url', 
                                'subscription_plan', 'max_employees', 'max_departments', 'status'];
        
        const updateFields = [];
        const updateValues = [];
        
        for (const field of allowedUpdates) {
            if (updates[field] !== undefined) {
                updateFields.push(`${field} = ?`);
                updateValues.push(updates[field]);
            }
        }
        
        if (updateFields.length === 0) {
            return res.status(400).json({
                success: false,
                message: "No valid fields to update"
            });
        }
        
        updateValues.push(id);
        const query = `UPDATE organizations SET ${updateFields.join(', ')} WHERE id = ?`;
        
        const [result] = await db.query(query, updateValues);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Organization not found"
            });
        }
        
        res.status(200).json({
            success: true,
            message: "Organization updated successfully"
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to update organization",
            error: err.message
        });
    }
};

// Update subscription
exports.updateSubscription = async (req, res) => {
    try {
        const { id } = req.params;
        const { subscription_plan, subscription_end_date, max_employees, max_departments } = req.body;
        
        const [result] = await db.query(
            `UPDATE organizations 
             SET subscription_plan = ?, subscription_end_date = ?, max_employees = ?, max_departments = ? 
             WHERE id = ?`,
            [subscription_plan, subscription_end_date, max_employees, max_departments, id]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Organization not found"
            });
        }
        
        res.status(200).json({
            success: true,
            message: "Subscription updated successfully"
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to update subscription",
            error: err.message
        });
    }
};

// Delete organization (soft delete by changing status)
exports.deleteOrganization = async (req, res) => {
    try {
        const { id } = req.params;
        
        const [result] = await db.query(
            "UPDATE organizations SET status = 'inactive' WHERE id = ?",
            [id]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Organization not found"
            });
        }
        
        res.status(200).json({
            success: true,
            message: "Organization deactivated successfully"
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to deactivate organization",
            error: err.message
        });
    }
};

// Get organization statistics
exports.getOrganizationStats = async (req, res) => {
    try {
        const { id } = req.params;
        
        const [stats] = await db.query(`
            SELECT 
                (SELECT COUNT(*) FROM users WHERE organization_id = ? AND role = 'employee') as total_employees,
                (SELECT COUNT(*) FROM users WHERE organization_id = ? AND role = 'hr_manager') as total_hr_managers,
                (SELECT COUNT(*) FROM departments WHERE organization_id = ? AND status = 'active') as total_departments,
                (SELECT COUNT(*) FROM designations WHERE organization_id = ? AND status = 'active') as total_designations,
                (SELECT COUNT(*) FROM employees WHERE organization_id = ? AND status = 'active') as active_employees,
                (SELECT COUNT(*) FROM employees WHERE organization_id = ? AND status = 'inactive') as inactive_employees,
                (SELECT COUNT(*) FROM employees WHERE organization_id = ? AND employment_type = 'full_time') as full_time_employees,
                (SELECT COUNT(*) FROM employees WHERE organization_id = ? AND employment_type = 'part_time') as part_time_employees
            `, [id, id, id, id, id, id, id, id]);
        
        res.status(200).json({
            success: true,
            data: stats[0]
        });
        
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "Failed to fetch organization statistics",
            error: err.message
        });
    }
};