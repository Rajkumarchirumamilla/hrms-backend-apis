

const express = require("express");
const { applyLeave, getMyLeaves, getLeaveBalance, updateLeaveStatus, approveLeave } = require("../controllers/leaveController");
const { verifyToken } = require("../middleware/authmiddleware");
const router = express.Router();




router.post("/apply-leave",verifyToken, applyLeave);
router.get("/my",verifyToken, getMyLeaves);
router.get("/balance", verifyToken,getLeaveBalance);
router.put("/id/status" ,updateLeaveStatus );

module.exports = router;