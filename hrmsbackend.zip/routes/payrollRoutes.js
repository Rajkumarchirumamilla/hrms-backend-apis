// routes/payrollRoutes.js
const express = require('express');
const router = express.Router();
const payrollController = require('../controllers/payrollController');

// Payroll routes
router.get('/payroll/:employeeId', payrollController.getEmployeePayroll);
router.post('/salary-structure', payrollController.createSalaryStructure);
router.post('/generate-payslip', payrollController.generatePayslip);
router.get('/payslips/:employeeId', payrollController.getEmployeePayslips);
router.get('/payslip/:id', payrollController.getPayslipById);
router.put('/payslip/:id/status', payrollController.updatePayslipStatus);
router.delete('/payslip/:id', payrollController.deletePayslip);
// Add this route
router.get('/payroll/download/:id', payrollController.downloadPayslip);

module.exports = router;